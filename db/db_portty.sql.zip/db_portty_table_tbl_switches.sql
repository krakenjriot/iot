
-- --------------------------------------------------------

--
-- Table structure for table `tbl_switches`
--

CREATE TABLE `tbl_switches` (
  `id` int(11) NOT NULL,
  `name` varchar(128) NOT NULL,
  `desc0` varchar(128) NOT NULL,
  `pin_num` int(2) NOT NULL,
  `board_name` varchar(128) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
