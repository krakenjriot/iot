
-- --------------------------------------------------------

--
-- Table structure for table `tbl_webservers`
--

CREATE TABLE `tbl_webservers` (
  `id` int(11) NOT NULL,
  `server_name` varchar(128) NOT NULL,
  `server_desc` varchar(128) NOT NULL,
  `server_ip` varchar(16) NOT NULL,
  `server_location` varchar(128) NOT NULL,
  `server_timezone` varchar(128) NOT NULL,
  `htdocs_dir` varchar(128) NOT NULL,
  `conf_dir` varchar(128) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_webservers`
--

INSERT INTO `tbl_webservers` (`id`, `server_name`, `server_desc`, `server_ip`, `server_location`, `server_timezone`, `htdocs_dir`, `conf_dir`) VALUES
(7, 'alcatraz', 'my home', '192.168.100.100', 'san pedro', '+3', 'c:xampphtdocs', 'c:	mpconf'),
(8, 'alcatraz2', 'my home3', '192.168.100.101', 'san pedro', '+3', 'c:\\xampp\\htdocs', 'c:\\tmp\\conf\\');
